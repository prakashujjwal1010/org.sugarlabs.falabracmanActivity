#ifndef GTV_H
#define GTV_H

#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

#include "smpeg.h"

#define FILENAME_BUFFER_SIZE 256

#ifdef __cplusplus
extern "C" {
#endif

/* Nothing here presently. */

#ifdef __cplusplus
}
#endif

#endif
